<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EstadisticasController;
use App\Http\Controllers\PruebasController;
use App\Http\Controllers\SintomasController;
use App\Http\Controllers\VacunasController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('/estadisticas',[EstadisticasController::class, 'get']);
Route::get('/estadisticas/{id}',[EstadisticasController::class, 'getById']);
Route::post('/estadisticas',[EstadisticasController::class, 'post']);
Route::put('/estadisticas/{id}',[EstadisticasController::class, 'put']);
Route::delete('/estadisticas/{id}',[EstadisticasController::class, 'delete']);
// API para pruebas
Route::get('/pruebas',[PruebasController::class, 'get']);
Route::get('/pruebas/{id}',[PruebasController::class, 'getById']);
Route::post('/pruebas',[PruebasController::class, 'post']);
Route::put('/pruebas/{id}',[PruebasController::class, 'put']);
Route::delete('/pruebas/{id}',[PruebasController::class, 'delete']);
// API para sintomas
Route::get('/sintomas',[SintomasController::class, 'get']);
Route::get('/sintomas/{id}',[SintomasController::class, 'getById']);
Route::post('/sintomas',[SintomasController::class, 'post']);
Route::put('/sintomas/{id}',[SintomasController::class, 'put']);
Route::delete('/sintomas/{id}',[SintomasController::class, 'delete']);
// API para vacunas
Route::get('/vacunas',[VacunasController::class, 'get']);
Route::get('/vacunas/{id}',[VacunasController::class, 'getById']);
Route::post('/vacunas',[VacunasController::class, 'post']);
Route::put('/vacunas/{id}',[VacunasController::class, 'put']);
Route::delete('/vacunas/{id}',[VacunasController::class, 'delete']);