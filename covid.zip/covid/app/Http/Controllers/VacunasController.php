<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Vacunas;
class VacunasController extends Controller
{
    public function get(){
        try {
            $vacunas= Vacunas::get();
            return response($vacunas,200);

        } catch (\Throwable $th) {
          return response($th,404);
        }
    }
    public function getById($id){
        try {
            $vacunas= Vacunas::find($id);
            return response($vacunas,200);
        } catch (\Throwable $th) {
          return response($th,404);
        }
    }
    public function post(Request $request){
        try {
            $vacunas = new Vacunas();
            $vacunas->nombre = $request->nombre;
            $vacunas->efectividad = $request->efectividad;
            $vacunas->paisDesarrollo = $request->paisDesarrollo;
            $vacunas->save();
            return response($vacunas,201);
        } catch (\Throwable $th) {
          return response($th,404);
        }
    }
    public function put(Request $request,$id){
        try {
            $vacunas =Vacunas::find($id);
            $vacunas->nombre = $request->nombre;
            $vacunas->efectividad = $request->efectividad;
            $vacunas->paisDesarrollo = $request->paisDesarrollo;
            $vacunas->update();
            return response($vacunas,200);
        } catch (\Throwable $th) {
          return response($th,404);
        }
    }
    public function delete($id){
        try {
            $vacunas= Vacunas::find($id);
            $vacunas->delete();
            return response('Se ha borrado con éxito',200);
        } catch (\Throwable $th) {
          return response($th,404);
        }
    }
}
