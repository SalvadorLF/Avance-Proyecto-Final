<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Sintomas;

class SintomasController extends Controller
{
    public function get(){
        try {
            $sintomas= Sintomas::get();
            return response($sintomas,200);

        } catch (\Throwable $th) {
          return response($th,404);
        }
    }
    public function getById($id){
        try {
            $sintomas= Sintomas::find($id);
            return response($sintomas,200);
        } catch (\Throwable $th) {
          return response($th,404);
        }
    }
    public function post(Request $request){
        try {
            $sintomas = new Sintomas();
            $sintomas->nombre = $request->nombre;
            $sintomas->tipoSintoma = $request->tipoSintoma;
            $sintomas->save();
            return response($sintomas,201);
        } catch (\Throwable $th) {
          return response($th,404);
        }
    }
    public function put(Request $request,$id){
        try {
            $sintomas =Sintomas::find($id);
            $sintomas->nombre = $request->nombre;
            $sintomas->tipoSintoma = $request->tipoSintoma;
            $sintomas->update();
            return response($sintomas,200);
        } catch (\Throwable $th) {
          return response($th,404);
        }
    }
    public function delete($id){
        try {
            $sintomas= sintomas::find($id);
            $sintomas->delete();
            return response('Se ha borrado con éxito',200);
        } catch (\Throwable $th) {
          return response($th,404);
        }
    }
}
